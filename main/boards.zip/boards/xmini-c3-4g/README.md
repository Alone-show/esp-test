# 开源地址

https://oshwhub.com/tenclass01/xmini_c3_4g

