#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

// 音频配置
#define AUDIO_INPUT_SAMPLE_RATE  16000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000

// 使用 Simplex I2S 模式
#define AUDIO_I2S_METHOD_SIMPLEX

#define AUDIO_I2S_MIC_GPIO_WS   GPIO_NUM_17
#define AUDIO_I2S_MIC_GPIO_SCK  GPIO_NUM_16
#define AUDIO_I2S_MIC_GPIO_DIN  GPIO_NUM_18
#define AUDIO_I2S_SPK_GPIO_DOUT GPIO_NUM_40
#define AUDIO_I2S_SPK_GPIO_BCLK GPIO_NUM_39
#define AUDIO_I2S_SPK_GPIO_LRCK GPIO_NUM_38

// 按钮配置
#define BOOT_BUTTON_GPIO        GPIO_NUM_0
#define TOUCH_BUTTON_GPIO       GPIO_NUM_14
// OLED显示屏配置 (SSD1306 128x64)
#define DISPLAY_SDA_PIN GPIO_NUM_12
#define DISPLAY_SCL_PIN GPIO_NUM_13
#define DISPLAY_WIDTH   128
#define DISPLAY_HEIGHT  64
#define DISPLAY_MIRROR_X false
#define DISPLAY_MIRROR_Y false

// 机器狗舵机配置 - 四条腿
#define LEFT_FRONT_LEG_PIN  GPIO_NUM_47  // 左前腿
#define LEFT_REAR_LEG_PIN   GPIO_NUM_21 // 左后腿
#define RIGHT_FRONT_LEG_PIN GPIO_NUM_9   // 右前腿
#define RIGHT_REAR_LEG_PIN  GPIO_NUM_10 // 右后腿

// EDA机器狗版本
#define EDA_ROBOT_PRO_VERSION "1.0.0"

#endif // _BOARD_CONFIG_H_