## 立创·实战派ESP32-C3开发板

1、开发板资料：https://wiki.lckfb.com/zh-hans/szpi-esp32c3

2、该开发板 flash 大小为 8MB，编译时注意选择合适的分区表：

```
Partition Table  --->
  Partition Table (Custom partition table CSV)  --->
  (partitions/v2/8m.csv) Custom partition CSV file
```
