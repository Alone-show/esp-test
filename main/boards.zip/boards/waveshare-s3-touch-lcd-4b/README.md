# Waveshare ESP32-S3-Touch-LCD-4B


[ESP32-S3-Touch-LCD-4B](https://www.waveshare.com/esp32-s3-touch-lcd-4b.htm) is waveshare electronics designed an intelligent 86 box based on ESP32-S3 module equipped with a 480*480 IPS capacitive touch screen


## Configuration

Configuration in `menuconfig`.

Selection Board Type `Xiaozhi Assistant --> Board Type`
- Waveshare ESP32-S3-Touch-LCD-4B